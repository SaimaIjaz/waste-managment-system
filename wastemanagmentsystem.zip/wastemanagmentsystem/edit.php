<?php

$servername = "localhost";
$user = "root";
$password = "";
$dbname = "wastemanagmentsystem";// 1st change database name

$conn = new mysqli($servername, $user,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else
{ 
//echo "Connected successfully";
}

if(isset($_GET['edit_id'])){
  
 $sql = "SELECT * FROM userinfo WHERE username=" .$_GET['edit_id'];
 // 2nd change table name and carno ya id jis ko ap change krna chaho
 $result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_array($result);

}
if(isset($_POST['btn-update'])){
 $username= $_POST['username'];
 $emailid = $_POST['emailid'];
 $contactno= $_POST['contactno'];
$complain= $_POST['complain'];
 
 $update = "UPDATE userinfo SET emailid='$emailid', contactno='$contactno'  , complain='$complain' where username='$username' ";
if ($conn->query($update) === TRUE) {
    echo "<script>alert('Do you want To update Record ?');</script>";
} else {
    echo "Error: " . $update . "<br>" . $conn->error;
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
 <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<form method="post">
<h1>Update Record</h1>
<input type="text" name="username" placeholder="User name" value="<?php echo $row['username']; ?>"><br>
<input type="text"  name="emailid" placeholder="Email ID" value="<?php echo $row['emailid']; ?>"><br>
<input type="text"  name="contactno" placeholder="Contact Number" value="<?php echo $row['contactno']; ?>"><br>
<input type="text" name="complain" placeholder="Complain" value="<?php echo $row['compalin']; ?>"><br>

<button type="submit" name="btn-update" id="btn-update" ><strong>Update</strong></button>
<a href="update.php"><button type="button" value="button">Cancel</button></a>
</form>

</body>
</html>