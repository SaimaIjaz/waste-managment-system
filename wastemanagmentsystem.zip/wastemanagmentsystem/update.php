<?php
$servername = "localhost";
$user = "root";
$password = "";
$dbname = "wastemanagmentsystem";

$conn = new mysqli($servername, $user,'',$dbname);


if ($conn->connect_error) {
  
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>


<!DOCTYPE html>
<html>
<head>
<title></title>
 <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">WASTE MANAGMENT SYSTEM</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">HOME</a>
         </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="userinfo.php">USER DATA</a>
      </li>
       </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="update.php">UPDATE</a>
      </li>
       </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="delete.php">DELETE</a>
      </li>
       <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="about.php">ABOUT US</a>
      </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<h1>****UPDATED RECORD****</h1>

<table border="5" align="center" style="line-height:30px">;
<tr>
<th align="center">User name</th>
<th align="center">Email ID</th>
<th align="center">Contact Number</th>
<th align="center">Complain</th>
<th align="center">Update</th>

</tr>
<?php
$sql = "SELECT * FROM userinfo";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['username'];?></td>
<td> <?php  echo $row['emailid'];?></td>
<td> <?php  echo $row['contactno'];?></td>
<td> <?php  echo $row['complain'];?></td>


 <td><a href="edit.php?edit_id=<?php echo $row['username']; ?>" alt="edit" >Edit/Update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>

</table>
<br><br><br><br><br><br><br>
<br><br><br><br><br><br><br>
<footer>
  <p class="p-3 bg-dark text-white">@WASTE MANAGMENT COMPANY</p>
</footer>
</body>
</html>