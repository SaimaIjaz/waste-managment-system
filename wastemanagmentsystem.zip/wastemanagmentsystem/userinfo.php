
<?php
$username= $_POST['username'];
$emailid= $_POST['emailid'];
$contactno= $_POST['contactno'];
$complain= $_POST['complain'];



$servername = "localhost";
$user = "root";
$password = "";
$dbname = "wastemanagmentsystem";

// Create connection
$conn = mysqli_connect($servername, $user,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}

$q="INSERT INTO userinfo VALUES('$username','$emailid','$contactno','$complain')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}

header('location:index.php');

?>