
<!DOCTYPE html>
<html>
<head>
<title></title>
 <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">WASTE MANAGMENT SYSTEM</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">HOME</a>
         </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="userinfo.php">USER DATA</a>
      </li>
       </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="update.php">UPDATE</a>
      </li>
       </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="delete.php">DELETE</a>
      </li>
       <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="about.php">ABOUT US</a>
      </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
  	 <div class="carousel-item">
      <img src="images/b1.jpg" alt="New York" width="1100" height="500"> 
    </div>
    <div class="carousel-item active">
      <img src="images/b2.jpg" alt="Los Angeles" width="1100" height="500">  
    </div>
    <div class="carousel-item">
      <img src="images/b3.jpg" alt="Chicago" width="1100" height="500">
      </div>   
    </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
 <section class="my-5">
 	<div class="py-5">
 		<h2 class="text-center">ABOUT US</h2>
 	</div>
 	<div class="container-fluid">
 	<div class="row">
 		 <div class="col-lg-6 col-md col-12">
 		 	<img src="images/b4.jpg" class="img-fluid aboutimg">
 		 </div>
 		  <div class="col-lg-6 col-md col-12">
 		 	<h2>WELCOME TO OUR WASTE MANAGMENT SYSTEM</h2>
 		 	<p class="py-4">We welcome you to our waste managment project. Here you can inform us about the details of your society and its current waste issues. We assure you to give our best results in removal of waste. We hope you enjoy using our services. Thank you!</p>
 		 	<a href="about.php" class="btn btn-success">More about us</a>
 		 </div>
 	</div>
 	</div>
 </section>
 <section class="my-5">
 	<div class="py-5">
 		<h2 class="text-center">OUR SERVICES</h2>
 	</div>
 	<div class="row">
 		<div class="col-lg-4 col-md-4 col-12">
 	<div class="card">
  <img class="card-img-top" src="images/b5.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Service 1</h4>
    <p class="card-text">Fluid and dry waste removal, with all hygiene!</p>
  </div>
  </div>
  </div>
  <div class="col-lg-4 col-md-4 col-12">
 	<div class="card">
  <img class="card-img-top" src="images/b6.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Service 2</h4>
    <p class="card-text">Waste managment in local areas as well as societies! </p>
  </div>
  </div>
  </div>
  <div class="col-lg-4 col-md-4 col-12">
 	<div class="card">
  <img class="card-img-top" src="images/b7.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Service 3</h4>
    <p class="card-text">Anywhere and anytime, waste removal and proper guidence!</p>
  </div>
  </div>
  </div>
</div>
 </section>

<section class="my-5">
	<div class="py-5">
		<h2 class="text-center">CONTACT US</h2>
	</div>
	<div class="w-50 m-auto">
		<form action="userinfo.php" method="POST">
			<div class="form-group">
				<label>Username</label>
				<input type="text" name="username" autocomplete="off" class="form-control">
			</div>
			<div class="form-group">
				<label>Email ID</label>
				<input type="text" name="emailid" autocomplete="off" class="form-control">
			</div>
			<div class="form-group">
				<label>Contact No</label>
				<input type="text" name="contactno" autocomplete="off" class="form-control">
			</div>
			<div class="form-group">
				<label>Complain</label>
				<input type="text" name="complain" autocomplete="off" class="form-control">
			</div>
			<button type="submit" class="btn  btn-success">Submit</button>
		</form>
	</div>
</section>
<footer>
	<p class="p-3 bg-dark text-white">@WASTE MANAGMENT COMPANY</p>
</footer>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>